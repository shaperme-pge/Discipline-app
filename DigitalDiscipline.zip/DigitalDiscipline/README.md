# Digital Discipline – Android App

A behavioral psychology–based Android app that reduces impulsive app usage through
friction, reflection, and self-awareness. Built in Kotlin with MVVM architecture.

---

## Features Implemented

| Feature | Status |
|---|---|
| Delay Timer before app launch | ✅ |
| Reverse Timer (reset on touch) | ✅ |
| Question-Based Unlock | ✅ |
| Voice-Based Reflection | ✅ |
| Micro Tasks Instead of Questions | ✅ |
| Escalation Timer | ✅ |
| Intent Confirmation (before/after) | ✅ |
| Regret Simulation message | ✅ |
| Distraction Score System | ✅ |
| Weekly Usage Report | ✅ |
| Streak & Reward tracking | ✅ |
| Goal-Based system | ✅ |
| Accountability Partners | ✅ |
| Emergency Calm Mode | ✅ |
| Custom App Selection | ✅ |
| Context-Aware Smart Mode (toggle) | ✅ |
| Custom Questions | ✅ |

---

## Architecture

```
com.digitaldiscipline/
├── DigitalDisciplineApp.kt          # Application class, notification channels
├── data/
│   ├── model/Models.kt              # Room entities: GuardedApp, UsageSession, etc.
│   ├── db/
│   │   ├── AppDatabase.kt           # Room database + seed data
│   │   └── Daos.kt                  # All DAOs
│   └── repository/
│       └── DisciplineRepository.kt  # Single source of truth
├── service/
│   ├── AppMonitorService.kt         # Foreground service polling foreground app
│   └── BootReceiver.kt              # Auto-start on device boot
└── ui/
    ├── MainActivity.kt              # Host + permission checks
    ├── home/                        # Dashboard: score, streak, goals, tip
    ├── apps/                        # Manage guarded apps + unlock mode
    ├── stats/                       # Weekly report + discipline rate
    ├── settings/                    # Goals, questions, partners, toggles
    └── unlock/
        └── UnlockActivity.kt        # The intercept overlay (core feature)
```

---

## How It Works

1. **AppMonitorService** runs as a foreground service and polls `UsageStatsManager` every second.
2. When a guarded app comes to the foreground, **UnlockActivity** launches as a full-screen overlay.
3. The user must complete a challenge (timer wait / question / task / voice) before the app opens.
4. Every interaction is recorded to Room DB and contributes to the daily **Distraction Score**.
5. The **Escalation Timer** increases the wait time with repeated attempts in the same session.

---

## Setup Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Kotlin 1.9.x
- A physical Android device (API 26+) — emulators can't test UsageStats reliably

### Step 1 – Add JitPack (for MPAndroidChart)
In your root `build.gradle`, add to `allprojects > repositories`:
```groovy
maven { url 'https://jitpack.io' }
```

### Step 2 – Open in Android Studio
```
File → Open → select the DigitalDiscipline/ folder
```

### Step 3 – Build & Run
```
Build → Make Project
Run → Run 'app'
```

### Step 4 – Grant Permissions (on device)
The app will prompt for two special permissions that **cannot be granted via runtime dialog**:

1. **Usage Access** – `Settings → Apps → Special App Access → Usage Access → Digital Discipline → Allow`
2. **Display over other apps** – `Settings → Apps → Digital Discipline → Display over other apps → Allow`

After granting, the monitor service starts automatically.

---

## Adding a Guarded App

1. Open the app → tap **My Apps** tab
2. Tap the **+** FAB
3. Select the app you want to guard (e.g. Instagram, YouTube)
4. Tap the gear icon on any app to change its **Unlock Mode**:
   - **Timer** – wait without touching the screen
   - **Question** – answer a reflective question (20+ characters)
   - **Task** – complete a breathing/typing exercise
   - **Voice** – speak your answer aloud

---

## Unlock Modes Explained

### Timer Mode (default)
A countdown appears. Any touch **resets** the timer (Reverse Timer mechanic). Once the timer completes without interaction, the "Open App" button activates.

### Question Mode
A random reflective question from the database is shown. The user must type at least 20 characters to proceed. 10 default questions are seeded; custom ones can be added in Settings.

### Task Mode
A random task is assigned: typing a sentence, a breathing exercise (30s timer), or other micro-activity.

### Voice Mode
Uses Android's built-in `SpeechRecognizer`. The user must speak a response of meaningful length before proceeding.

---

## Escalation Timer

When `escalationEnabled = true`, repeated attempts to open the same app within 60 seconds escalate the delay:

```
Attempt 1 → 10 seconds
Attempt 2 → 20 seconds
Attempt 3 → 60 seconds (1 minute)
Attempt 4+ → 180 seconds (3 minutes)
```

The level resets automatically after 60 seconds of no attempts.

---

## Scoring System

| Action | Points |
|---|---|
| Blocked / chose not to open | +5 |
| Opened with intent answered | +2 |
| Opened impulsively | −3 |

Scores accumulate daily and drive the streak counter (more avoided than indulged = good day ✅).

---

## Extending the App

### Add AI Behavior Insights
Replace the static tips in `HomeFragment` with a call to an LLM API, passing the last 7 days of `UsageSession` data as context.

### Add Location-Aware Smart Mode
Use `FusedLocationProviderClient` in `AppMonitorService` to detect work/home location and adjust `isEnabled` per-app accordingly.

### Add Notification Reports
Use `WorkManager` to schedule a nightly `Worker` that emails accountability partners via the device's mail app if the day's score is below a threshold.

### Add Lottie Animations
Replace the `ProgressBar` in the Timer panel with a Lottie animation for a more polished feel. A breathing animation is ideal for the Calm Mode.

---

## Dependencies

| Library | Purpose |
|---|---|
| Room 2.6 | Local database |
| Navigation Component 2.7 | Fragment navigation |
| ViewModel + LiveData | MVVM |
| WorkManager 2.9 | Background scheduling |
| Material Components 1.10 | UI |
| MPAndroidChart 3.1 | Charts (stats screen) |
| Lottie 6.1 | Animations |
| Coroutines 1.7 | Async |
| DataStore Preferences | Settings persistence |

---

## License
MIT – free to use, modify, and distribute.

---

*Built from the product concept by Mark Andreo, Product Manager.*
