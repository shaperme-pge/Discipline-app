package com.digitaldiscipline.service

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.digitaldiscipline.DigitalDisciplineApp
import com.digitaldiscipline.data.repository.DisciplineRepository
import com.digitaldiscipline.ui.unlock.UnlockActivity
import kotlinx.coroutines.*

/**
 * Foreground service that polls the foreground app every second.
 * When a guarded app comes to the foreground, we launch UnlockActivity
 * as a full-screen overlay to intercept the user.
 */
class AppMonitorService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var repository: DisciplineRepository
    private lateinit var usageStatsManager: UsageStatsManager

    private var lastInterceptedPkg: String? = null
    private var lastInterceptTime: Long = 0L

    companion object {
        const val NOTIFICATION_ID = 1001
        const val POLL_INTERVAL_MS = 1000L
        const val RE_INTERCEPT_COOLDOWN_MS = 5000L // don't re-intercept same app for 5s

        fun start(context: Context) {
            val intent = Intent(context, AppMonitorService::class.java)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AppMonitorService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = DisciplineRepository(this)
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startMonitoring()
        return START_STICKY
    }

    private fun startMonitoring() {
        scope.launch {
            while (isActive) {
                checkForegroundApp()
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private suspend fun checkForegroundApp() {
        val currentPkg = getForegroundPackage() ?: return
        if (currentPkg == packageName) return // ignore our own app

        val enabledApps = repository.getEnabledApps()
        val guardedApp = enabledApps.find { it.packageName == currentPkg } ?: return

        val now = System.currentTimeMillis()
        val isSameRecentIntercept = currentPkg == lastInterceptedPkg
                && (now - lastInterceptTime) < RE_INTERCEPT_COOLDOWN_MS

        if (isSameRecentIntercept) return

        // Launch intercept overlay
        lastInterceptedPkg = currentPkg
        lastInterceptTime = now

        val delaySeconds = repository.recordAttemptAndGetDelay(guardedApp)

        val unlockIntent = Intent(this@AppMonitorService, UnlockActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(UnlockActivity.EXTRA_PACKAGE_NAME, currentPkg)
            putExtra(UnlockActivity.EXTRA_APP_NAME, guardedApp.appName)
            putExtra(UnlockActivity.EXTRA_DELAY_SECONDS, delaySeconds)
            putExtra(UnlockActivity.EXTRA_UNLOCK_MODE, guardedApp.unlockMode.name)
        }
        startActivity(unlockIntent)
    }

    private fun getForegroundPackage(): String? {
        val now = System.currentTimeMillis()
        val stats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            now - 10_000L,
            now
        )
        return stats?.maxByOrNull { it.lastTimeUsed }?.packageName
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, DigitalDisciplineApp.CHANNEL_ID_MONITOR)
            .setContentTitle("Digital Discipline Active")
            .setContentText("Monitoring your app usage")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
