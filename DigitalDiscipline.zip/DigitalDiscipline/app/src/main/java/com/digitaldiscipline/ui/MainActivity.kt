package com.digitaldiscipline.ui

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.digitaldiscipline.R
import com.digitaldiscipline.databinding.ActivityMainBinding
import com.digitaldiscipline.service.AppMonitorService
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        val appBarConfig = AppBarConfiguration(
            setOf(R.id.nav_home, R.id.nav_apps, R.id.nav_stats, R.id.nav_settings)
        )
        setupActionBarWithNavController(navController, appBarConfig)
        binding.bottomNav.setupWithNavController(navController)

        checkRequiredPermissions()
    }

    private fun checkRequiredPermissions() {
        if (!hasUsageStatsPermission()) {
            showUsageStatsPermissionDialog()
        } else if (!Settings.canDrawOverlays(this)) {
            showOverlayPermissionDialog()
        } else {
            AppMonitorService.start(this)
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun showUsageStatsPermissionDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Usage Access Required")
            .setMessage(
                "Digital Discipline needs Usage Access permission to monitor which apps you open. " +
                "Please enable it in the next screen."
            )
            .setPositiveButton("Grant Permission") { _, _ ->
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
            .setNegativeButton("Not Now", null)
            .show()
    }

    private fun showOverlayPermissionDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Overlay Permission Required")
            .setMessage(
                "Digital Discipline needs to display over other apps to show the discipline screen. " +
                "Please enable 'Appear on top' in the next screen."
            )
            .setPositiveButton("Grant Permission") { _, _ ->
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
            .setNegativeButton("Not Now", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        // Re-check after returning from settings
        if (hasUsageStatsPermission() && Settings.canDrawOverlays(this)) {
            AppMonitorService.start(this)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
