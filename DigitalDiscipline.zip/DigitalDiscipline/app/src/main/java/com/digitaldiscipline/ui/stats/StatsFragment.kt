package com.digitaldiscipline.ui.stats

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.digitaldiscipline.databinding.FragmentStatsBinding

class StatsFragment : Fragment() {

    private var _binding: FragmentStatsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: StatsViewModel by viewModels { StatsViewModelFactory(requireContext()) }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentStatsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.weeklyStats.observe(viewLifecycleOwner) { stats ->
            binding.tvTotalAttempts.text = "Total app attempts: ${stats.totalAttempts}"
            binding.tvAvoided.text = "✅ Distractions avoided: ${stats.distractionsAvoided}"
            binding.tvIndulged.text = "❌ Opened anyway: ${stats.distractionsIndulged}"

            val rate = if (stats.totalAttempts > 0)
                (stats.distractionsAvoided * 100 / stats.totalAttempts) else 0
            binding.tvSuccessRate.text = "Discipline rate: $rate%"
            binding.progressDiscipline.progress = rate

            val peakHour = stats.peakDistractionHour
            binding.tvPeakHour.text = if (peakHour != null) {
                val amPm = if (peakHour < 12) "AM" else "PM"
                val hour12 = if (peakHour % 12 == 0) 12 else peakHour % 12
                "📈 Peak distraction: $hour12:00 $amPm"
            } else "No peak data yet"

            binding.tvTopApp.text = stats.topDistractingApp?.let {
                "📱 Most distracting: $it"
            } ?: "No data yet"
        }

        viewModel.last30Days.observe(viewLifecycleOwner) { scores ->
            // Simple text-based chart for now; with MPAndroidChart you'd populate a BarChart here
            val summary = scores.takeLast(7).joinToString("\n") { score ->
                val indicator = if (score.distractionsAvoided >= score.distractionsIndulged) "✅" else "❌"
                "$indicator ${score.date}  +${score.distractionsAvoided} / -${score.distractionsIndulged}"
            }
            binding.tvWeekChart.text = if (summary.isNotBlank()) summary else "Start using the app to see your stats!"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
