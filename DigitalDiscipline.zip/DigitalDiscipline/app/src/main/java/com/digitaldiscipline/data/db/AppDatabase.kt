package com.digitaldiscipline.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.digitaldiscipline.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        GuardedApp::class,
        UsageSession::class,
        ReflectiveQuestion::class,
        DailyScore::class,
        Goal::class,
        AccountabilityPartner::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun guardedAppDao(): GuardedAppDao
    abstract fun usageSessionDao(): UsageSessionDao
    abstract fun questionDao(): QuestionDao
    abstract fun dailyScoreDao(): DailyScoreDao
    abstract fun goalDao(): GoalDao
    abstract fun accountabilityPartnerDao(): AccountabilityPartnerDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "digital_discipline.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed default reflective questions
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.questionDao()?.let { dao ->
                                    defaultQuestions.forEach { dao.insert(it) }
                                }
                            }
                        }
                    })
                    .build()
                    .also { INSTANCE = it }
            }
        }

        private val defaultQuestions = listOf(
            ReflectiveQuestion(text = "Why are you opening this app right now?"),
            ReflectiveQuestion(text = "What is the one thing you planned to accomplish today that you haven't done yet?"),
            ReflectiveQuestion(text = "If your future self could see you right now, would they be proud?"),
            ReflectiveQuestion(text = "What will you gain by opening this app? What might you lose?"),
            ReflectiveQuestion(text = "Name three things you're grateful for today before you continue."),
            ReflectiveQuestion(text = "Is there something more important you should be doing right now?"),
            ReflectiveQuestion(text = "How does this app use help you get closer to your goals?"),
            ReflectiveQuestion(text = "What would you do with your time if this app didn't exist?"),
            ReflectiveQuestion(text = "Are you bored, stressed, or avoiding something? What is it?"),
            ReflectiveQuestion(text = "What is one productive thing you could do in the next 10 minutes instead?")
        )
    }
}
