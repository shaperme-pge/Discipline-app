package com.digitaldiscipline.ui.settings

import android.content.Context
import androidx.lifecycle.*
import com.digitaldiscipline.data.repository.DisciplineRepository
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: DisciplineRepository) : ViewModel() {

    val activeGoals = repository.activeGoals
    val activePartners = repository.activePartners

    fun addGoal(title: String) = viewModelScope.launch { repository.addGoal(title) }
    fun addPartner(name: String, email: String) = viewModelScope.launch { repository.addPartner(name, email) }
    fun addQuestion(text: String) = viewModelScope.launch { repository.addQuestion(text) }

    // These would persist to DataStore in a full implementation
    fun setEscalationEnabled(enabled: Boolean) { /* save to prefs */ }
    fun setSmartModeEnabled(enabled: Boolean) { /* save to prefs */ }
}

class SettingsViewModelFactory(private val ctx: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return SettingsViewModel(DisciplineRepository(ctx)) as T
    }
}
