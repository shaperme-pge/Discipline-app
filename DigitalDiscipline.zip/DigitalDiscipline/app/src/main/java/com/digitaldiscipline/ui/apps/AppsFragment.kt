package com.digitaldiscipline.ui.apps

import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.digitaldiscipline.databinding.FragmentAppsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class AppsFragment : Fragment() {

    private var _binding: FragmentAppsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppsViewModel by viewModels { AppsViewModelFactory(requireContext()) }
    private lateinit var adapter: GuardedAppsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAppsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = GuardedAppsAdapter(
            onToggle = { app, enabled -> viewModel.toggleApp(app, enabled) },
            onSettings = { app -> showAppSettingsDialog(app) },
            onRemove = { app -> viewModel.removeApp(app.packageName) }
        )
        binding.rvApps.layoutManager = LinearLayoutManager(requireContext())
        binding.rvApps.adapter = adapter

        viewModel.allApps.observe(viewLifecycleOwner) { apps ->
            adapter.submitList(apps)
            binding.tvEmpty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.fabAddApp.setOnClickListener { showAddAppDialog() }
    }

    private fun showAddAppDialog() {
        val pm = requireContext().packageManager
        val installedApps = pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
            .sortedBy { pm.getApplicationLabel(it).toString() }

        val labels = installedApps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        var selected = -1

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Select App to Guard")
            .setSingleChoiceItems(labels, -1) { _, which -> selected = which }
            .setPositiveButton("Add") { _, _ ->
                if (selected >= 0) {
                    val info = installedApps[selected]
                    viewModel.addApp(
                        packageName = info.packageName,
                        appName = labels[selected]
                    )
                    Toast.makeText(requireContext(), "${labels[selected]} added", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAppSettingsDialog(app: com.digitaldiscipline.data.model.GuardedApp) {
        val modes = com.digitaldiscipline.data.model.UnlockMode.values().map { it.name }.toTypedArray()
        var selectedMode = app.unlockMode.ordinal

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Settings for ${app.appName}")
            .setSingleChoiceItems(modes, selectedMode) { _, which -> selectedMode = which }
            .setPositiveButton("Save") { _, _ ->
                val newMode = com.digitaldiscipline.data.model.UnlockMode.values()[selectedMode]
                viewModel.updateUnlockMode(app, newMode)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
