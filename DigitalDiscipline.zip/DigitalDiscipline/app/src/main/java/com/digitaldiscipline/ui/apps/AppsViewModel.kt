package com.digitaldiscipline.ui.apps

import android.content.Context
import android.view.*
import androidx.lifecycle.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.digitaldiscipline.data.model.GuardedApp
import com.digitaldiscipline.data.model.UnlockMode
import com.digitaldiscipline.data.repository.DisciplineRepository
import com.digitaldiscipline.databinding.ItemGuardedAppBinding
import kotlinx.coroutines.launch

// ── ViewModel ─────────────────────────────────────────────────────────────────
class AppsViewModel(private val repository: DisciplineRepository) : ViewModel() {
    val allApps = repository.allApps

    fun addApp(packageName: String, appName: String) {
        viewModelScope.launch {
            repository.addApp(GuardedApp(packageName = packageName, appName = appName))
        }
    }

    fun toggleApp(app: GuardedApp, enabled: Boolean) {
        viewModelScope.launch { repository.updateApp(app.copy(isEnabled = enabled)) }
    }

    fun updateUnlockMode(app: GuardedApp, mode: UnlockMode) {
        viewModelScope.launch { repository.updateApp(app.copy(unlockMode = mode)) }
    }

    fun removeApp(pkg: String) {
        viewModelScope.launch { repository.removeApp(pkg) }
    }
}

class AppsViewModelFactory(private val ctx: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return AppsViewModel(DisciplineRepository(ctx)) as T
    }
}

// ── Adapter ──────────────────────────────────────────────────────────────────
class GuardedAppsAdapter(
    private val onToggle: (GuardedApp, Boolean) -> Unit,
    private val onSettings: (GuardedApp) -> Unit,
    private val onRemove: (GuardedApp) -> Unit
) : ListAdapter<GuardedApp, GuardedAppsAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemGuardedAppBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemGuardedAppBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = getItem(position)
        with(holder.binding) {
            tvAppName.text = app.appName
            tvUnlockMode.text = "Mode: ${app.unlockMode.name.lowercase().replaceFirstChar { it.uppercase() }}"
            switchEnabled.isChecked = app.isEnabled
            switchEnabled.setOnCheckedChangeListener { _, checked -> onToggle(app, checked) }
            btnSettings.setOnClickListener { onSettings(app) }
            btnRemove.setOnClickListener { onRemove(app) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<GuardedApp>() {
            override fun areItemsTheSame(a: GuardedApp, b: GuardedApp) = a.packageName == b.packageName
            override fun areContentsTheSame(a: GuardedApp, b: GuardedApp) = a == b
        }
    }
}
