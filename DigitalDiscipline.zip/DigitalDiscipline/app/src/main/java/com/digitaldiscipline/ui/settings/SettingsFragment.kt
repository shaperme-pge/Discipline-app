package com.digitaldiscipline.ui.settings

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.digitaldiscipline.databinding.FragmentSettingsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels { SettingsViewModelFactory(requireContext()) }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Goals section
        viewModel.activeGoals.observe(viewLifecycleOwner) { goals ->
            binding.tvGoalsList.text = if (goals.isEmpty()) "No goals set yet."
            else goals.joinToString("\n") { "• ${it.title}" }
        }

        binding.btnAddGoal.setOnClickListener {
            val input = android.widget.EditText(requireContext()).apply {
                hint = "Enter your goal"
            }
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add Goal")
                .setView(input)
                .setPositiveButton("Add") { _, _ ->
                    val title = input.text.toString().trim()
                    if (title.isNotEmpty()) viewModel.addGoal(title)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Accountability partner
        binding.btnAddPartner.setOnClickListener {
            val nameInput = android.widget.EditText(requireContext()).apply { hint = "Partner name" }
            val emailInput = android.widget.EditText(requireContext()).apply {
                hint = "Partner email"
                inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            }
            val layout = android.widget.LinearLayout(requireContext()).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                setPadding(48, 16, 48, 0)
                addView(nameInput)
                addView(emailInput)
            }
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add Accountability Partner")
                .setView(layout)
                .setPositiveButton("Add") { _, _ ->
                    val name = nameInput.text.toString().trim()
                    val email = emailInput.text.toString().trim()
                    if (name.isNotEmpty() && email.isNotEmpty()) {
                        viewModel.addPartner(name, email)
                        Toast.makeText(requireContext(), "$name added as partner", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        viewModel.activePartners.observe(viewLifecycleOwner) { partners ->
            binding.tvPartnersList.text = if (partners.isEmpty()) "No partners added."
            else partners.joinToString("\n") { "• ${it.name} (${it.email})" }
        }

        // Custom questions
        binding.btnAddQuestion.setOnClickListener {
            val input = android.widget.EditText(requireContext()).apply {
                hint = "Enter your reflective question"
            }
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add Custom Question")
                .setView(input)
                .setPositiveButton("Add") { _, _ ->
                    val q = input.text.toString().trim()
                    if (q.isNotEmpty()) {
                        viewModel.addQuestion(q)
                        Toast.makeText(requireContext(), "Question added!", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Escalation toggle
        binding.switchEscalation.setOnCheckedChangeListener { _, checked ->
            viewModel.setEscalationEnabled(checked)
            Toast.makeText(
                requireContext(),
                if (checked) "Escalating timer ON" else "Escalating timer OFF",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Context-aware smart mode
        binding.switchSmartMode.setOnCheckedChangeListener { _, checked ->
            viewModel.setSmartModeEnabled(checked)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
