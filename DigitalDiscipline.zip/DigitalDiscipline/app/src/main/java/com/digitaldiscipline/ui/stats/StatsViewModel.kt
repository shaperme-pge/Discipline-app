package com.digitaldiscipline.ui.stats

import android.content.Context
import androidx.lifecycle.*
import com.digitaldiscipline.data.repository.DisciplineRepository
import com.digitaldiscipline.data.repository.WeeklyStats
import kotlinx.coroutines.launch

class StatsViewModel(private val repository: DisciplineRepository) : ViewModel() {

    val last30Days = repository.last30DaysScores

    val weeklyStats: LiveData<WeeklyStats> = liveData {
        emit(repository.getWeeklyStats())
    }
}

class StatsViewModelFactory(private val ctx: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return StatsViewModel(DisciplineRepository(ctx)) as T
    }
}
