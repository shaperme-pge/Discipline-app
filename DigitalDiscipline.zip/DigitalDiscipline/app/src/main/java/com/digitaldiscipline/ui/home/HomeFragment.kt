package com.digitaldiscipline.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.digitaldiscipline.databinding.FragmentHomeBinding
import java.text.SimpleDateFormat
import java.util.*

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels { HomeViewModelFactory(requireContext()) }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Greeting
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        binding.tvGreeting.text = when {
            hour < 12 -> "Good morning 🌅"
            hour < 17 -> "Good afternoon ☀️"
            else -> "Good evening 🌙"
        }

        // Date
        binding.tvDate.text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())

        // Observe today's score
        viewModel.todayScore.observe(viewLifecycleOwner) { score ->
            binding.tvScore.text = (score?.totalScore ?: 0).toString()
            binding.tvAvoided.text = "Avoided: ${score?.distractionsAvoided ?: 0}"
            binding.tvIndulged.text = "Opened anyway: ${score?.distractionsIndulged ?: 0}"
        }

        // Observe streak
        viewModel.currentStreak.observe(viewLifecycleOwner) { streak ->
            binding.tvStreak.text = "🔥 $streak day streak"
        }

        // Observe active goals
        viewModel.activeGoals.observe(viewLifecycleOwner) { goals ->
            binding.tvGoalCount.text = "${goals.size} active goal(s)"
        }

        // Motivational tip of the day
        val tips = listOf(
            "Every time you resist an impulse, you strengthen your willpower.",
            "The apps are designed to be addictive. You are stronger than the algorithm.",
            "A 10-second pause can change a 30-minute mindless scroll.",
            "Your attention is your most valuable resource. Spend it wisely.",
            "Progress is not perfection. Every avoided distraction counts."
        )
        binding.tvTip.text = tips[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % tips.size]
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
