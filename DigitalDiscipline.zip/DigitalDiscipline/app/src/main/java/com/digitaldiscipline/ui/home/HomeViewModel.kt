package com.digitaldiscipline.ui.home

import android.content.Context
import androidx.lifecycle.*
import com.digitaldiscipline.data.model.DailyScore
import com.digitaldiscipline.data.model.Goal
import com.digitaldiscipline.data.repository.DisciplineRepository
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: DisciplineRepository) : ViewModel() {

    val todayScore: LiveData<DailyScore?> = liveData {
        emit(repository.getTodayScore())
    }

    val activeGoals: LiveData<List<Goal>> = repository.activeGoals

    val currentStreak: LiveData<Int> = repository.last30DaysScores.map { scores ->
        var streak = 0
        for (score in scores) {
            if (score.distractionsAvoided > score.distractionsIndulged) streak++
            else break
        }
        streak
    }
}

class HomeViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return HomeViewModel(DisciplineRepository(context)) as T
    }
}
