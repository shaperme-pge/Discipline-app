package com.digitaldiscipline.data.repository

import android.content.Context
import com.digitaldiscipline.data.db.AppDatabase
import com.digitaldiscipline.data.model.*
import java.text.SimpleDateFormat
import java.util.*

class DisciplineRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val guardedAppDao = db.guardedAppDao()
    private val sessionDao = db.usageSessionDao()
    private val questionDao = db.questionDao()
    private val scoreDao = db.dailyScoreDao()
    private val goalDao = db.goalDao()
    private val partnerDao = db.accountabilityPartnerDao()

    // ── Guarded Apps ──────────────────────────────────────────────────────────
    val allApps = guardedAppDao.getAllApps()

    suspend fun getEnabledApps() = guardedAppDao.getEnabledApps()
    suspend fun getApp(pkg: String) = guardedAppDao.getApp(pkg)
    suspend fun addApp(app: GuardedApp) = guardedAppDao.insert(app)
    suspend fun updateApp(app: GuardedApp) = guardedAppDao.update(app)
    suspend fun removeApp(pkg: String) = guardedAppDao.deleteByPackage(pkg)

    /**
     * Called each time a guarded app is attempted. Returns the current delay in seconds.
     * Escalates the timer if repeated attempts happen within the same minute.
     */
    suspend fun recordAttemptAndGetDelay(app: GuardedApp): Int {
        val escalationDelays = listOf(10, 20, 60, 180)
        val now = System.currentTimeMillis()
        val withinWindow = (now - app.lastAttemptTimestamp) < 60_000L

        val newLevel = if (app.escalationEnabled && withinWindow) {
            (app.currentEscalationLevel + 1).coerceAtMost(escalationDelays.size - 1)
        } else {
            0
        }
        guardedAppDao.updateEscalation(app.packageName, newLevel, now)
        return escalationDelays[newLevel]
    }

    // ── Usage Sessions ────────────────────────────────────────────────────────
    val recentSessions = sessionDao.getRecentSessions()

    suspend fun startSession(pkg: String, appName: String): Long {
        return sessionDao.insert(UsageSession(packageName = pkg, appName = appName))
    }

    suspend fun closeSession(id: Long, wasBlocked: Boolean, intentAnswered: Boolean) {
        val session = sessionDao.getById(id) ?: return
        val score = when {
            wasBlocked -> +5
            intentAnswered -> +2
            else -> -3
        }
        sessionDao.update(
            session.copy(
                closedAt = System.currentTimeMillis(),
                wasBlocked = wasBlocked,
                intentAnswered = intentAnswered,
                distractionScore = score
            )
        )
        updateDailyScore(wasBlocked)
    }

    // ── Daily Score ───────────────────────────────────────────────────────────
    val last30DaysScores = scoreDao.getLast30Days()

    private suspend fun updateDailyScore(avoided: Boolean) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val existing = scoreDao.getByDate(today) ?: DailyScore(date = today)
        val updated = existing.copy(
            totalScore = existing.totalScore + if (avoided) 5 else -3,
            distractionsAvoided = existing.distractionsAvoided + if (avoided) 1 else 0,
            distractionsIndulged = existing.distractionsIndulged + if (avoided) 0 else 1
        )
        scoreDao.upsert(updated)
    }

    suspend fun getTodayScore(): DailyScore? {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return scoreDao.getByDate(today)
    }

    // ── Questions ─────────────────────────────────────────────────────────────
    val allQuestions = questionDao.getAllQuestions()

    suspend fun getRandomQuestion() = questionDao.getRandomQuestion()
    suspend fun addQuestion(text: String) = questionDao.insert(ReflectiveQuestion(text = text, isCustom = true))
    suspend fun deleteQuestion(q: ReflectiveQuestion) = questionDao.delete(q)

    // ── Goals ─────────────────────────────────────────────────────────────────
    val allGoals = goalDao.getAllGoals()
    val activeGoals = goalDao.getActiveGoals()

    suspend fun addGoal(title: String, desc: String = "") =
        goalDao.insert(Goal(title = title, description = desc))

    suspend fun completeGoal(goal: Goal) = goalDao.update(goal.copy(isCompleted = true))
    suspend fun deleteGoal(goal: Goal) = goalDao.delete(goal)

    // ── Accountability Partners ───────────────────────────────────────────────
    val activePartners = partnerDao.getActivePartners()

    suspend fun addPartner(name: String, email: String) =
        partnerDao.insert(AccountabilityPartner(name = name, email = email))

    suspend fun removePartner(partner: AccountabilityPartner) =
        partnerDao.update(partner.copy(isActive = false))

    // ── Weekly Report ─────────────────────────────────────────────────────────
    suspend fun getWeeklyStats(): WeeklyStats {
        val weekAgo = System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000L
        val sessions = sessionDao.getSessionsSince(weekAgo)
        val avoided = sessions.count { it.wasBlocked }
        val indulged = sessions.count { !it.wasBlocked }

        // Peak distraction hour
        val hourCounts = sessions
            .filter { !it.wasBlocked }
            .groupBy {
                Calendar.getInstance().apply { timeInMillis = it.openedAt }.get(Calendar.HOUR_OF_DAY)
            }
            .mapValues { it.value.size }
        val peakHour = hourCounts.maxByOrNull { it.value }?.key

        return WeeklyStats(
            totalAttempts = sessions.size,
            distractionsAvoided = avoided,
            distractionsIndulged = indulged,
            peakDistractionHour = peakHour,
            topDistractingApp = sessions
                .filter { !it.wasBlocked }
                .groupBy { it.appName }
                .maxByOrNull { it.value.size }?.key
        )
    }
}

data class WeeklyStats(
    val totalAttempts: Int,
    val distractionsAvoided: Int,
    val distractionsIndulged: Int,
    val peakDistractionHour: Int?,
    val topDistractingApp: String?
)
