package com.digitaldiscipline

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.digitaldiscipline.data.db.AppDatabase

class DigitalDisciplineApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    companion object {
        const val CHANNEL_ID_MONITOR = "dd_monitor_channel"
        const val CHANNEL_ID_ALERTS  = "dd_alerts_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val monitorChannel = NotificationChannel(
                CHANNEL_ID_MONITOR,
                "App Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps Digital Discipline running in the background" }

            val alertChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                "Discipline Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Notifications about your discipline streaks and goals" }

            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannels(listOf(monitorChannel, alertChannel))
        }
    }
}
