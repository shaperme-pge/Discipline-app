package com.digitaldiscipline.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// ── Guarded App ──────────────────────────────────────────────────────────────
@Entity(tableName = "guarded_apps")
data class GuardedApp(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isEnabled: Boolean = true,
    val delaySeconds: Int = 10,           // base delay
    val unlockMode: UnlockMode = UnlockMode.TIMER,
    val escalationEnabled: Boolean = true,
    val currentEscalationLevel: Int = 0,  // 0=10s,1=20s,2=60s,3=180s
    val lastAttemptTimestamp: Long = 0L
)

enum class UnlockMode { TIMER, QUESTION, TASK, VOICE }

// ── Usage Session ────────────────────────────────────────────────────────────
@Entity(tableName = "usage_sessions")
data class UsageSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val openedAt: Long = System.currentTimeMillis(),
    val closedAt: Long = 0L,
    val wasBlocked: Boolean = false,       // user chose NOT to open after delay
    val intentAnswered: Boolean = false,
    val distractionScore: Int = 0          // negative = distracted, positive = intentional
)

// ── Reflective Question ──────────────────────────────────────────────────────
@Entity(tableName = "questions")
data class ReflectiveQuestion(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val category: String = "general",
    val isCustom: Boolean = false
)

// ── Daily Score ──────────────────────────────────────────────────────────────
@Entity(tableName = "daily_scores")
data class DailyScore(
    @PrimaryKey val date: String,          // "2026-04-12"
    val totalScore: Int = 0,
    val distractionsAvoided: Int = 0,
    val distractionsIndulged: Int = 0,
    val streakDay: Int = 0
)

// ── Goal ─────────────────────────────────────────────────────────────────────
@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ── Accountability Partner ───────────────────────────────────────────────────
@Entity(tableName = "accountability_partners")
data class AccountabilityPartner(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val isActive: Boolean = true
)
