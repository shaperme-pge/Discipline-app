package com.digitaldiscipline.ui.unlock

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.speech.RecognizerIntent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.digitaldiscipline.R
import com.digitaldiscipline.data.model.UnlockMode
import com.digitaldiscipline.data.repository.DisciplineRepository
import com.digitaldiscipline.databinding.ActivityUnlockBinding
import kotlinx.coroutines.launch
import java.util.Locale

class UnlockActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_pkg"
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_DELAY_SECONDS = "extra_delay"
        const val EXTRA_UNLOCK_MODE = "extra_unlock_mode"
    }

    private lateinit var binding: ActivityUnlockBinding
    private lateinit var repository: DisciplineRepository

    private var packageName_: String = ""
    private var appName: String = ""
    private var delaySeconds: Int = 10
    private var unlockMode: UnlockMode = UnlockMode.TIMER

    private var countDownTimer: CountDownTimer? = null
    private var sessionId: Long = -1L
    private var reverseTimerActive = false
    private var reverseTimer: CountDownTimer? = null
    private var currentQuestion: String = ""

    // Voice recognition launcher
    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull() ?: ""
        if (spoken.length > 10) {
            binding.tvVoiceResult.text = "✓ Recorded: \"$spoken\""
            binding.btnProceedVoice.isEnabled = true
        } else {
            Toast.makeText(this, "Please give a longer answer", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )

        binding = ActivityUnlockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = DisciplineRepository(this)

        packageName_ = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
        appName = intent.getStringExtra(EXTRA_APP_NAME) ?: "App"
        delaySeconds = intent.getIntExtra(EXTRA_DELAY_SECONDS, 10)
        unlockMode = UnlockMode.valueOf(
            intent.getStringExtra(EXTRA_UNLOCK_MODE) ?: UnlockMode.TIMER.name
        )

        binding.tvAppName.text = appName
        binding.tvRegretMessage.text =
            "If you spend 30 minutes on $appName, that's 30 minutes away from your goals."

        lifecycleScope.launch {
            sessionId = repository.startSession(packageName_, appName)
        }

        setupUnlockMode()
        setupButtons()
    }

    private fun setupUnlockMode() {
        // Hide all panels first
        binding.panelTimer.visibility = View.GONE
        binding.panelQuestion.visibility = View.GONE
        binding.panelTask.visibility = View.GONE
        binding.panelVoice.visibility = View.GONE

        when (unlockMode) {
            UnlockMode.TIMER   -> setupTimerMode()
            UnlockMode.QUESTION -> setupQuestionMode()
            UnlockMode.TASK    -> setupTaskMode()
            UnlockMode.VOICE   -> setupVoiceMode()
        }
    }

    // ── TIMER MODE ─────────────────────────────────────────────────────────────
    private fun setupTimerMode() {
        binding.panelTimer.visibility = View.VISIBLE
        binding.tvTimerHint.text = "Wait $delaySeconds seconds without touching the screen"
        startReverseTimer()
    }

    private fun startReverseTimer() {
        reverseTimerActive = true
        binding.progressTimer.max = delaySeconds
        reverseTimer?.cancel()
        reverseTimer = object : CountDownTimer(delaySeconds * 1000L, 100) {
            override fun onTick(millisLeft: Long) {
                val elapsed = delaySeconds - (millisLeft / 1000).toInt()
                binding.progressTimer.progress = elapsed
                binding.tvTimerCount.text = (millisLeft / 1000 + 1).toString()
            }
            override fun onFinish() {
                binding.tvTimerCount.text = "✓"
                binding.btnProceedTimer.isEnabled = true
                binding.tvTimerHint.text = "You may now open $appName"
            }
        }.start()
    }

    // Reset timer on screen touch (reverse timer mechanic)
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (reverseTimerActive && event?.action == MotionEvent.ACTION_DOWN) {
            binding.tvTimerHint.text = "Timer reset! Keep your hands off the screen."
            startReverseTimer()
        }
        return super.onTouchEvent(event)
    }

    // ── QUESTION MODE ──────────────────────────────────────────────────────────
    private fun setupQuestionMode() {
        binding.panelQuestion.visibility = View.VISIBLE
        lifecycleScope.launch {
            val q = repository.getRandomQuestion()
            currentQuestion = q?.text ?: "Why do you want to open this app right now?"
            binding.tvQuestion.text = currentQuestion
        }
        binding.etAnswer.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                binding.btnProceedQuestion.isEnabled = (s?.length ?: 0) >= 20
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    // ── TASK MODE ──────────────────────────────────────────────────────────────
    private fun setupTaskMode() {
        binding.panelTask.visibility = View.VISIBLE
        val tasks = listOf(
            "Type the sentence: 'I am in control of my time and attention.'",
            "Do 10 deep breaths slowly before continuing.",
            "Write down one thing you're grateful for today.",
            "Do 5 jumping jacks before you continue.",
            "Close your eyes and breathe for 30 seconds."
        )
        val task = tasks.random()
        binding.tvTask.text = task

        if (task.startsWith("Type")) {
            binding.etTaskInput.visibility = View.VISIBLE
            binding.etTaskInput.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) {
                    binding.btnProceedTask.isEnabled = (s?.length ?: 0) >= 15
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        } else {
            // Timer-based task
            binding.etTaskInput.visibility = View.GONE
            object : CountDownTimer(30_000, 1000) {
                override fun onTick(ms: Long) {
                    binding.btnProceedTask.text = "Continue (${ms / 1000}s)"
                }
                override fun onFinish() {
                    binding.btnProceedTask.isEnabled = true
                    binding.btnProceedTask.text = "Continue"
                }
            }.start()
        }
    }

    // ── VOICE MODE ─────────────────────────────────────────────────────────────
    private fun setupVoiceMode() {
        binding.panelVoice.visibility = View.VISIBLE
        lifecycleScope.launch {
            val q = repository.getRandomQuestion()
            binding.tvVoiceQuestion.text = q?.text ?: "Why do you want to open this app?"
        }
        binding.btnRecord.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell us why you want to open this app...")
            }
            speechLauncher.launch(intent)
        }
    }

    // ── BUTTONS ────────────────────────────────────────────────────────────────
    private fun setupButtons() {
        binding.btnCancel.setOnClickListener { cancelAndGoHome() }

        binding.btnProceedTimer.setOnClickListener { proceedToApp() }
        binding.btnProceedQuestion.setOnClickListener { proceedToApp() }
        binding.btnProceedTask.setOnClickListener { proceedToApp() }
        binding.btnProceedVoice.setOnClickListener { proceedToApp() }

        binding.btnCalm.setOnClickListener { openCalmMode() }
    }

    private fun proceedToApp() {
        lifecycleScope.launch {
            repository.closeSession(sessionId, wasBlocked = false, intentAnswered = true)
        }
        // Bring target app back to foreground
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName_)
        launchIntent?.let { startActivity(it) }
        finish()
    }

    private fun cancelAndGoHome() {
        lifecycleScope.launch {
            repository.closeSession(sessionId, wasBlocked = true, intentAnswered = false)
        }
        // Go home instead
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    private fun openCalmMode() {
        Toast.makeText(this, "Opening calm mode… (breathing exercise)", Toast.LENGTH_LONG).show()
        // In a full implementation, navigate to CalmActivity
        cancelAndGoHome()
    }

    override fun onBackPressed() {
        cancelAndGoHome()
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        reverseTimer?.cancel()
        super.onDestroy()
    }
}
