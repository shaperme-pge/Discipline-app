package com.digitaldiscipline.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.digitaldiscipline.data.model.*

// ── Guarded App DAO ───────────────────────────────────────────────────────────
@Dao
interface GuardedAppDao {
    @Query("SELECT * FROM guarded_apps ORDER BY appName ASC")
    fun getAllApps(): LiveData<List<GuardedApp>>

    @Query("SELECT * FROM guarded_apps WHERE isEnabled = 1")
    suspend fun getEnabledApps(): List<GuardedApp>

    @Query("SELECT * FROM guarded_apps WHERE packageName = :pkg LIMIT 1")
    suspend fun getApp(pkg: String): GuardedApp?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(app: GuardedApp)

    @Update
    suspend fun update(app: GuardedApp)

    @Delete
    suspend fun delete(app: GuardedApp)

    @Query("DELETE FROM guarded_apps WHERE packageName = :pkg")
    suspend fun deleteByPackage(pkg: String)

    @Query("UPDATE guarded_apps SET currentEscalationLevel = :level, lastAttemptTimestamp = :ts WHERE packageName = :pkg")
    suspend fun updateEscalation(pkg: String, level: Int, ts: Long)
}

// ── Usage Session DAO ─────────────────────────────────────────────────────────
@Dao
interface UsageSessionDao {
    @Query("SELECT * FROM usage_sessions ORDER BY openedAt DESC LIMIT 200")
    fun getRecentSessions(): LiveData<List<UsageSession>>

    @Query("SELECT * FROM usage_sessions WHERE openedAt >= :since ORDER BY openedAt DESC")
    suspend fun getSessionsSince(since: Long): List<UsageSession>

    @Query("SELECT COUNT(*) FROM usage_sessions WHERE wasBlocked = 1 AND openedAt >= :since")
    suspend fun countAvoided(since: Long): Int

    @Query("SELECT COUNT(*) FROM usage_sessions WHERE wasBlocked = 0 AND openedAt >= :since")
    suspend fun countIndulged(since: Long): Int

    @Insert
    suspend fun insert(session: UsageSession): Long

    @Update
    suspend fun update(session: UsageSession)

    @Query("SELECT * FROM usage_sessions WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): UsageSession?
}

// ── Question DAO ──────────────────────────────────────────────────────────────
@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions ORDER BY RANDOM() LIMIT 1")
    suspend fun getRandomQuestion(): ReflectiveQuestion?

    @Query("SELECT * FROM questions ORDER BY id ASC")
    fun getAllQuestions(): LiveData<List<ReflectiveQuestion>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(question: ReflectiveQuestion)

    @Delete
    suspend fun delete(question: ReflectiveQuestion)
}

// ── Daily Score DAO ───────────────────────────────────────────────────────────
@Dao
interface DailyScoreDao {
    @Query("SELECT * FROM daily_scores ORDER BY date DESC LIMIT 30")
    fun getLast30Days(): LiveData<List<DailyScore>>

    @Query("SELECT * FROM daily_scores WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): DailyScore?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(score: DailyScore)
}

// ── Goal DAO ──────────────────────────────────────────────────────────────────
@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY createdAt DESC")
    fun getAllGoals(): LiveData<List<Goal>>

    @Query("SELECT * FROM goals WHERE isCompleted = 0 ORDER BY createdAt DESC")
    fun getActiveGoals(): LiveData<List<Goal>>

    @Insert
    suspend fun insert(goal: Goal): Long

    @Update
    suspend fun update(goal: Goal)

    @Delete
    suspend fun delete(goal: Goal)
}

// ── Accountability Partner DAO ────────────────────────────────────────────────
@Dao
interface AccountabilityPartnerDao {
    @Query("SELECT * FROM accountability_partners WHERE isActive = 1")
    fun getActivePartners(): LiveData<List<AccountabilityPartner>>

    @Insert
    suspend fun insert(partner: AccountabilityPartner): Long

    @Update
    suspend fun update(partner: AccountabilityPartner)

    @Delete
    suspend fun delete(partner: AccountabilityPartner)
}
